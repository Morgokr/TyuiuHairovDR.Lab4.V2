﻿namespace Tyuiu.HairovDR.Lab4
{
    partial class OrdinaryCalcControl
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            ButtonsPanel = new Panel();
            TableLayoutPanel = new TableLayoutPanel();
            button0YMG = new Button();
            button2YMG = new Button();
            button8YMG = new Button();
            button9YMG = new Button();
            button6YMG = new Button();
            button3YMG = new Button();
            button7YMG = new Button();
            button4YMG = new Button();
            button5YMG = new Button();
            button1YMG = new Button();
            InversButtonYMG = new Button();
            CommaButtonYMG = new Button();
            EqualButtonYMG = new Button();
            DelButtonYMG = new Button();
            QuotientButtonYMG = new Button();
            MinusButtonYMG = new Button();
            PlusButtonYMG = new Button();
            MultiplicationButtonYMG = new Button();
            PowerButtonYMG = new Button();
            RootButtonYMG = new Button();
            ScreenPanel = new Panel();
            ScreenTableLayout = new TableLayoutPanel();
            FirstPartLabelYMG = new Label();
            SecondPartLabelYMG = new Label();
            ButtonsPanel.SuspendLayout();
            TableLayoutPanel.SuspendLayout();
            ScreenPanel.SuspendLayout();
            ScreenTableLayout.SuspendLayout();
            SuspendLayout();
            // 
            // ButtonsPanel
            // 
            ButtonsPanel.Controls.Add(TableLayoutPanel);
            ButtonsPanel.Dock = DockStyle.Fill;
            ButtonsPanel.Location = new Point(0, 133);
            ButtonsPanel.Margin = new Padding(3, 4, 3, 4);
            ButtonsPanel.Name = "ButtonsPanel";
            ButtonsPanel.Size = new Size(1336, 676);
            ButtonsPanel.TabIndex = 3;
            // 
            // TableLayoutPanel
            // 
            TableLayoutPanel.BackColor = SystemColors.ControlDarkDark;
            TableLayoutPanel.ColumnCount = 5;
            TableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 19.9992027F));
            TableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 19.9991989F));
            TableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 19.9991989F));
            TableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 19.9992027F));
            TableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20.0031986F));
            TableLayoutPanel.Controls.Add(button0YMG, 1, 3);
            TableLayoutPanel.Controls.Add(button2YMG, 1, 2);
            TableLayoutPanel.Controls.Add(button8YMG, 1, 0);
            TableLayoutPanel.Controls.Add(button9YMG, 2, 0);
            TableLayoutPanel.Controls.Add(button6YMG, 2, 1);
            TableLayoutPanel.Controls.Add(button3YMG, 2, 2);
            TableLayoutPanel.Controls.Add(button7YMG, 0, 0);
            TableLayoutPanel.Controls.Add(button4YMG, 0, 1);
            TableLayoutPanel.Controls.Add(button5YMG, 1, 1);
            TableLayoutPanel.Controls.Add(button1YMG, 0, 2);
            TableLayoutPanel.Controls.Add(InversButtonYMG, 0, 3);
            TableLayoutPanel.Controls.Add(CommaButtonYMG, 2, 3);
            TableLayoutPanel.Controls.Add(EqualButtonYMG, 4, 3);
            TableLayoutPanel.Controls.Add(DelButtonYMG, 4, 2);
            TableLayoutPanel.Controls.Add(QuotientButtonYMG, 4, 1);
            TableLayoutPanel.Controls.Add(MinusButtonYMG, 4, 0);
            TableLayoutPanel.Controls.Add(PlusButtonYMG, 3, 0);
            TableLayoutPanel.Controls.Add(MultiplicationButtonYMG, 3, 1);
            TableLayoutPanel.Controls.Add(PowerButtonYMG, 3, 2);
            TableLayoutPanel.Controls.Add(RootButtonYMG, 3, 3);
            TableLayoutPanel.Dock = DockStyle.Fill;
            TableLayoutPanel.Location = new Point(0, 0);
            TableLayoutPanel.Margin = new Padding(3, 4, 3, 4);
            TableLayoutPanel.Name = "TableLayoutPanel";
            TableLayoutPanel.RowCount = 4;
            TableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            TableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            TableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            TableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            TableLayoutPanel.Size = new Size(1336, 676);
            TableLayoutPanel.TabIndex = 0;
            // 
            // button0YMG
            // 
            button0YMG.BackColor = SystemColors.ActiveCaption;
            button0YMG.Cursor = Cursors.Hand;
            button0YMG.Dock = DockStyle.Fill;
            button0YMG.FlatStyle = FlatStyle.Popup;
            button0YMG.Font = new Font("Arial", 36F, FontStyle.Bold);
            button0YMG.Location = new Point(270, 511);
            button0YMG.Margin = new Padding(3, 4, 3, 4);
            button0YMG.Name = "button0YMG";
            button0YMG.Size = new Size(261, 161);
            button0YMG.TabIndex = 0;
            button0YMG.Text = "0";
            button0YMG.UseVisualStyleBackColor = false;
            button0YMG.Click += button0_Click;
            // 
            // button2YMG
            // 
            button2YMG.BackColor = SystemColors.ActiveCaption;
            button2YMG.Cursor = Cursors.Hand;
            button2YMG.Dock = DockStyle.Fill;
            button2YMG.FlatStyle = FlatStyle.Popup;
            button2YMG.Font = new Font("Arial", 36F, FontStyle.Bold);
            button2YMG.Location = new Point(270, 342);
            button2YMG.Margin = new Padding(3, 4, 3, 4);
            button2YMG.Name = "button2YMG";
            button2YMG.Size = new Size(261, 161);
            button2YMG.TabIndex = 1;
            button2YMG.Text = "2";
            button2YMG.UseVisualStyleBackColor = false;
            button2YMG.Click += button2_Click;
            // 
            // button8YMG
            // 
            button8YMG.BackColor = SystemColors.ActiveCaption;
            button8YMG.Cursor = Cursors.Hand;
            button8YMG.Dock = DockStyle.Fill;
            button8YMG.FlatStyle = FlatStyle.Popup;
            button8YMG.Font = new Font("Arial", 36F, FontStyle.Bold);
            button8YMG.Location = new Point(270, 4);
            button8YMG.Margin = new Padding(3, 4, 3, 4);
            button8YMG.Name = "button8YMG";
            button8YMG.Size = new Size(261, 161);
            button8YMG.TabIndex = 2;
            button8YMG.Text = "8";
            button8YMG.UseVisualStyleBackColor = false;
            button8YMG.Click += button8_Click;
            // 
            // button9YMG
            // 
            button9YMG.BackColor = SystemColors.ActiveCaption;
            button9YMG.Cursor = Cursors.Hand;
            button9YMG.Dock = DockStyle.Fill;
            button9YMG.FlatStyle = FlatStyle.Popup;
            button9YMG.Font = new Font("Arial", 36F, FontStyle.Bold);
            button9YMG.Location = new Point(537, 4);
            button9YMG.Margin = new Padding(3, 4, 3, 4);
            button9YMG.Name = "button9YMG";
            button9YMG.Size = new Size(261, 161);
            button9YMG.TabIndex = 3;
            button9YMG.Text = "9";
            button9YMG.UseVisualStyleBackColor = false;
            button9YMG.Click += button9_Click;
            // 
            // button6YMG
            // 
            button6YMG.BackColor = SystemColors.ActiveCaption;
            button6YMG.Cursor = Cursors.Hand;
            button6YMG.Dock = DockStyle.Fill;
            button6YMG.FlatStyle = FlatStyle.Popup;
            button6YMG.Font = new Font("Arial", 36F, FontStyle.Bold);
            button6YMG.Location = new Point(537, 173);
            button6YMG.Margin = new Padding(3, 4, 3, 4);
            button6YMG.Name = "button6YMG";
            button6YMG.Size = new Size(261, 161);
            button6YMG.TabIndex = 4;
            button6YMG.Text = "6";
            button6YMG.UseVisualStyleBackColor = false;
            button6YMG.Click += button6_Click;
            // 
            // button3YMG
            // 
            button3YMG.BackColor = SystemColors.ActiveCaption;
            button3YMG.Cursor = Cursors.Hand;
            button3YMG.Dock = DockStyle.Fill;
            button3YMG.FlatStyle = FlatStyle.Popup;
            button3YMG.Font = new Font("Arial", 36F, FontStyle.Bold);
            button3YMG.Location = new Point(537, 342);
            button3YMG.Margin = new Padding(3, 4, 3, 4);
            button3YMG.Name = "button3YMG";
            button3YMG.Size = new Size(261, 161);
            button3YMG.TabIndex = 5;
            button3YMG.Text = "3";
            button3YMG.UseVisualStyleBackColor = false;
            button3YMG.Click += button3_Click;
            // 
            // button7YMG
            // 
            button7YMG.BackColor = SystemColors.ActiveCaption;
            button7YMG.Cursor = Cursors.Hand;
            button7YMG.Dock = DockStyle.Fill;
            button7YMG.FlatStyle = FlatStyle.Popup;
            button7YMG.Font = new Font("Arial", 36F, FontStyle.Bold);
            button7YMG.Location = new Point(3, 4);
            button7YMG.Margin = new Padding(3, 4, 3, 4);
            button7YMG.Name = "button7YMG";
            button7YMG.Size = new Size(261, 161);
            button7YMG.TabIndex = 6;
            button7YMG.Text = "7";
            button7YMG.UseVisualStyleBackColor = false;
            button7YMG.Click += button7_Click;
            // 
            // button4YMG
            // 
            button4YMG.BackColor = SystemColors.ActiveCaption;
            button4YMG.Cursor = Cursors.Hand;
            button4YMG.Dock = DockStyle.Fill;
            button4YMG.FlatStyle = FlatStyle.Popup;
            button4YMG.Font = new Font("Arial", 36F, FontStyle.Bold);
            button4YMG.Location = new Point(3, 173);
            button4YMG.Margin = new Padding(3, 4, 3, 4);
            button4YMG.Name = "button4YMG";
            button4YMG.Size = new Size(261, 161);
            button4YMG.TabIndex = 7;
            button4YMG.Text = "4";
            button4YMG.UseVisualStyleBackColor = false;
            button4YMG.Click += button4_Click;
            // 
            // button5YMG
            // 
            button5YMG.BackColor = SystemColors.ActiveCaption;
            button5YMG.Cursor = Cursors.Hand;
            button5YMG.Dock = DockStyle.Fill;
            button5YMG.FlatStyle = FlatStyle.Popup;
            button5YMG.Font = new Font("Arial", 36F, FontStyle.Bold);
            button5YMG.Location = new Point(270, 173);
            button5YMG.Margin = new Padding(3, 4, 3, 4);
            button5YMG.Name = "button5YMG";
            button5YMG.Size = new Size(261, 161);
            button5YMG.TabIndex = 8;
            button5YMG.Text = "5";
            button5YMG.UseVisualStyleBackColor = false;
            button5YMG.Click += button5_Click;
            // 
            // button1YMG
            // 
            button1YMG.BackColor = SystemColors.ActiveCaption;
            button1YMG.Cursor = Cursors.Hand;
            button1YMG.Dock = DockStyle.Fill;
            button1YMG.FlatStyle = FlatStyle.Popup;
            button1YMG.Font = new Font("Arial", 36F, FontStyle.Bold);
            button1YMG.Location = new Point(3, 342);
            button1YMG.Margin = new Padding(3, 4, 3, 4);
            button1YMG.Name = "button1YMG";
            button1YMG.Size = new Size(261, 161);
            button1YMG.TabIndex = 9;
            button1YMG.Text = "1";
            button1YMG.UseVisualStyleBackColor = false;
            button1YMG.Click += button1_Click;
            // 
            // InversButtonYMG
            // 
            InversButtonYMG.BackColor = SystemColors.ActiveCaption;
            InversButtonYMG.Cursor = Cursors.Hand;
            InversButtonYMG.Dock = DockStyle.Fill;
            InversButtonYMG.FlatStyle = FlatStyle.Popup;
            InversButtonYMG.Font = new Font("Arial", 36F, FontStyle.Bold);
            InversButtonYMG.Location = new Point(3, 511);
            InversButtonYMG.Margin = new Padding(3, 4, 3, 4);
            InversButtonYMG.Name = "InversButtonYMG";
            InversButtonYMG.Size = new Size(261, 161);
            InversButtonYMG.TabIndex = 10;
            InversButtonYMG.Text = "+/-";
            InversButtonYMG.UseVisualStyleBackColor = false;
            InversButtonYMG.Click += InversButton_Click;
            // 
            // CommaButtonYMG
            // 
            CommaButtonYMG.BackColor = SystemColors.ActiveCaption;
            CommaButtonYMG.Cursor = Cursors.Hand;
            CommaButtonYMG.Dock = DockStyle.Fill;
            CommaButtonYMG.FlatStyle = FlatStyle.Popup;
            CommaButtonYMG.Font = new Font("Arial", 36F, FontStyle.Bold);
            CommaButtonYMG.Location = new Point(537, 511);
            CommaButtonYMG.Margin = new Padding(3, 4, 3, 4);
            CommaButtonYMG.Name = "CommaButtonYMG";
            CommaButtonYMG.Size = new Size(261, 161);
            CommaButtonYMG.TabIndex = 11;
            CommaButtonYMG.Text = ",";
            CommaButtonYMG.UseVisualStyleBackColor = false;
            CommaButtonYMG.Click += CommaButton_Click;
            // 
            // EqualButtonYMG
            // 
            EqualButtonYMG.BackColor = SystemColors.ActiveCaption;
            EqualButtonYMG.Cursor = Cursors.Hand;
            EqualButtonYMG.Dock = DockStyle.Fill;
            EqualButtonYMG.FlatStyle = FlatStyle.Popup;
            EqualButtonYMG.Font = new Font("Arial", 36F, FontStyle.Bold);
            EqualButtonYMG.Location = new Point(1071, 511);
            EqualButtonYMG.Margin = new Padding(3, 4, 3, 4);
            EqualButtonYMG.Name = "EqualButtonYMG";
            EqualButtonYMG.Size = new Size(262, 161);
            EqualButtonYMG.TabIndex = 15;
            EqualButtonYMG.Text = "=";
            EqualButtonYMG.UseVisualStyleBackColor = false;
            EqualButtonYMG.Click += EqualButton_Click;
            // 
            // DelButtonYMG
            // 
            DelButtonYMG.BackColor = SystemColors.ActiveCaption;
            DelButtonYMG.Cursor = Cursors.Hand;
            DelButtonYMG.Dock = DockStyle.Fill;
            DelButtonYMG.FlatStyle = FlatStyle.Popup;
            DelButtonYMG.Font = new Font("Arial", 36F, FontStyle.Bold);
            DelButtonYMG.Location = new Point(1071, 342);
            DelButtonYMG.Margin = new Padding(3, 4, 3, 4);
            DelButtonYMG.Name = "DelButtonYMG";
            DelButtonYMG.Size = new Size(262, 161);
            DelButtonYMG.TabIndex = 14;
            DelButtonYMG.Text = " ⌦";
            DelButtonYMG.UseVisualStyleBackColor = false;
            DelButtonYMG.Click += DelButton_Click;
            // 
            // QuotientButtonYMG
            // 
            QuotientButtonYMG.BackColor = SystemColors.ActiveCaption;
            QuotientButtonYMG.Cursor = Cursors.Hand;
            QuotientButtonYMG.Dock = DockStyle.Fill;
            QuotientButtonYMG.FlatStyle = FlatStyle.Popup;
            QuotientButtonYMG.Font = new Font("Arial", 36F, FontStyle.Bold);
            QuotientButtonYMG.Location = new Point(1071, 173);
            QuotientButtonYMG.Margin = new Padding(3, 4, 3, 4);
            QuotientButtonYMG.Name = "QuotientButtonYMG";
            QuotientButtonYMG.Size = new Size(262, 161);
            QuotientButtonYMG.TabIndex = 13;
            QuotientButtonYMG.Text = "/";
            QuotientButtonYMG.UseVisualStyleBackColor = false;
            QuotientButtonYMG.Click += QuotientButton_Click;
            // 
            // MinusButtonYMG
            // 
            MinusButtonYMG.BackColor = SystemColors.ActiveCaption;
            MinusButtonYMG.Cursor = Cursors.Hand;
            MinusButtonYMG.Dock = DockStyle.Fill;
            MinusButtonYMG.FlatStyle = FlatStyle.Popup;
            MinusButtonYMG.Font = new Font("Arial", 36F, FontStyle.Bold);
            MinusButtonYMG.Location = new Point(1071, 4);
            MinusButtonYMG.Margin = new Padding(3, 4, 3, 4);
            MinusButtonYMG.Name = "MinusButtonYMG";
            MinusButtonYMG.Size = new Size(262, 161);
            MinusButtonYMG.TabIndex = 12;
            MinusButtonYMG.Text = "-";
            MinusButtonYMG.UseVisualStyleBackColor = false;
            MinusButtonYMG.Click += MinusButton_Click;
            // 
            // PlusButtonYMG
            // 
            PlusButtonYMG.BackColor = SystemColors.ActiveCaption;
            PlusButtonYMG.Cursor = Cursors.Hand;
            PlusButtonYMG.Dock = DockStyle.Fill;
            PlusButtonYMG.FlatStyle = FlatStyle.Popup;
            PlusButtonYMG.Font = new Font("Arial", 36F, FontStyle.Bold);
            PlusButtonYMG.Location = new Point(804, 4);
            PlusButtonYMG.Margin = new Padding(3, 4, 3, 4);
            PlusButtonYMG.Name = "PlusButtonYMG";
            PlusButtonYMG.Size = new Size(261, 161);
            PlusButtonYMG.TabIndex = 16;
            PlusButtonYMG.Text = "+";
            PlusButtonYMG.UseVisualStyleBackColor = false;
            PlusButtonYMG.Click += PlusButton_Click;
            // 
            // MultiplicationButtonYMG
            // 
            MultiplicationButtonYMG.BackColor = SystemColors.ActiveCaption;
            MultiplicationButtonYMG.Cursor = Cursors.Hand;
            MultiplicationButtonYMG.Dock = DockStyle.Fill;
            MultiplicationButtonYMG.FlatStyle = FlatStyle.Popup;
            MultiplicationButtonYMG.Font = new Font("Arial", 36F, FontStyle.Bold);
            MultiplicationButtonYMG.Location = new Point(804, 173);
            MultiplicationButtonYMG.Margin = new Padding(3, 4, 3, 4);
            MultiplicationButtonYMG.Name = "MultiplicationButtonYMG";
            MultiplicationButtonYMG.Size = new Size(261, 161);
            MultiplicationButtonYMG.TabIndex = 17;
            MultiplicationButtonYMG.Text = "X";
            MultiplicationButtonYMG.UseVisualStyleBackColor = false;
            MultiplicationButtonYMG.Click += MultiplicationButton_Click;
            // 
            // PowerButtonYMG
            // 
            PowerButtonYMG.BackColor = SystemColors.ActiveCaption;
            PowerButtonYMG.Cursor = Cursors.Hand;
            PowerButtonYMG.Dock = DockStyle.Fill;
            PowerButtonYMG.FlatStyle = FlatStyle.Popup;
            PowerButtonYMG.Font = new Font("Arial", 36F, FontStyle.Bold);
            PowerButtonYMG.Location = new Point(804, 342);
            PowerButtonYMG.Margin = new Padding(3, 4, 3, 4);
            PowerButtonYMG.Name = "PowerButtonYMG";
            PowerButtonYMG.Size = new Size(261, 161);
            PowerButtonYMG.TabIndex = 18;
            PowerButtonYMG.Text = "^";
            PowerButtonYMG.UseVisualStyleBackColor = false;
            PowerButtonYMG.Click += PowerButton_Click;
            // 
            // RootButtonYMG
            // 
            RootButtonYMG.BackColor = SystemColors.ActiveCaption;
            RootButtonYMG.Cursor = Cursors.Hand;
            RootButtonYMG.Dock = DockStyle.Fill;
            RootButtonYMG.FlatStyle = FlatStyle.Popup;
            RootButtonYMG.Font = new Font("Arial", 36F, FontStyle.Bold);
            RootButtonYMG.Location = new Point(804, 511);
            RootButtonYMG.Margin = new Padding(3, 4, 3, 4);
            RootButtonYMG.Name = "RootButtonYMG";
            RootButtonYMG.Size = new Size(261, 161);
            RootButtonYMG.TabIndex = 19;
            RootButtonYMG.Text = "√";
            RootButtonYMG.UseVisualStyleBackColor = false;
            RootButtonYMG.Click += RootButton_Click;
            // 
            // ScreenPanel
            // 
            ScreenPanel.Controls.Add(ScreenTableLayout);
            ScreenPanel.Dock = DockStyle.Top;
            ScreenPanel.Location = new Point(0, 0);
            ScreenPanel.Margin = new Padding(3, 4, 3, 4);
            ScreenPanel.Name = "ScreenPanel";
            ScreenPanel.Size = new Size(1336, 133);
            ScreenPanel.TabIndex = 4;
            // 
            // ScreenTableLayout
            // 
            ScreenTableLayout.ColumnCount = 1;
            ScreenTableLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            ScreenTableLayout.Controls.Add(FirstPartLabelYMG, 0, 0);
            ScreenTableLayout.Controls.Add(SecondPartLabelYMG, 0, 1);
            ScreenTableLayout.Dock = DockStyle.Fill;
            ScreenTableLayout.Location = new Point(0, 0);
            ScreenTableLayout.Margin = new Padding(3, 4, 3, 4);
            ScreenTableLayout.Name = "ScreenTableLayout";
            ScreenTableLayout.RowCount = 2;
            ScreenTableLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            ScreenTableLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            ScreenTableLayout.Size = new Size(1336, 133);
            ScreenTableLayout.TabIndex = 0;
            // 
            // FirstPartLabelYMG
            // 
            FirstPartLabelYMG.AutoSize = true;
            FirstPartLabelYMG.BackColor = SystemColors.ActiveCaption;
            FirstPartLabelYMG.Dock = DockStyle.Fill;
            FirstPartLabelYMG.FlatStyle = FlatStyle.Popup;
            FirstPartLabelYMG.Font = new Font("Arial", 25.8000011F, FontStyle.Bold);
            FirstPartLabelYMG.ForeColor = SystemColors.ActiveCaptionText;
            FirstPartLabelYMG.Location = new Point(3, 0);
            FirstPartLabelYMG.Name = "FirstPartLabelYMG";
            FirstPartLabelYMG.Size = new Size(1330, 66);
            FirstPartLabelYMG.TabIndex = 0;
            FirstPartLabelYMG.Text = "первая половина";
            FirstPartLabelYMG.TextAlign = ContentAlignment.MiddleRight;
            // 
            // SecondPartLabelYMG
            // 
            SecondPartLabelYMG.AutoSize = true;
            SecondPartLabelYMG.BackColor = SystemColors.ActiveCaption;
            SecondPartLabelYMG.Dock = DockStyle.Fill;
            SecondPartLabelYMG.FlatStyle = FlatStyle.Popup;
            SecondPartLabelYMG.Font = new Font("Arial", 25.8000011F, FontStyle.Bold);
            SecondPartLabelYMG.ForeColor = SystemColors.ActiveCaptionText;
            SecondPartLabelYMG.Location = new Point(3, 66);
            SecondPartLabelYMG.Name = "SecondPartLabelYMG";
            SecondPartLabelYMG.Size = new Size(1330, 67);
            SecondPartLabelYMG.TabIndex = 1;
            SecondPartLabelYMG.Text = "вторая половина";
            SecondPartLabelYMG.TextAlign = ContentAlignment.MiddleRight;
            // 
            // OrdinaryCalcControl
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(ButtonsPanel);
            Controls.Add(ScreenPanel);
            Margin = new Padding(3, 4, 3, 4);
            Name = "OrdinaryCalcControl";
            Size = new Size(1336, 809);
            ButtonsPanel.ResumeLayout(false);
            TableLayoutPanel.ResumeLayout(false);
            ScreenPanel.ResumeLayout(false);
            ScreenTableLayout.ResumeLayout(false);
            ScreenTableLayout.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private Panel ButtonsPanel;
        private TableLayoutPanel TableLayoutPanel;
        private Button button0YMG;
        private Button button2YMG;
        private Button button8YMG;
        private Button button9YMG;
        private Button button6YMG;
        private Button button3YMG;
        private Button button7YMG;
        private Button button4YMG;
        private Button button5YMG;
        private Button button1YMG;
        private Button InversButtonYMG;
        private Button CommaButtonYMG;
        private Button EqualButtonYMG;
        private Button DelButtonYMG;
        private Button QuotientButtonYMG;
        private Button MinusButtonYMG;
        private Button PlusButtonYMG;
        private Button MultiplicationButtonYMG;
        private Button PowerButtonYMG;
        private Button RootButtonYMG;
        private Panel ScreenPanel;
        private TableLayoutPanel ScreenTableLayout;
        private Label FirstPartLabelYMG;
        private Label SecondPartLabelYMG;
    }
}
