﻿namespace Tyuiu.HairovDR.Lab4
{
    partial class ArithmeticCalcControl
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            ButtonsPanel = new Panel();
            TableLayoutPanel = new TableLayoutPanel();
            button0YMG = new Button();
            button2YMG = new Button();
            button8YMG = new Button();
            button9YMG = new Button();
            button6YMG = new Button();
            button3YMG = new Button();
            button7YMG = new Button();
            button4YMG = new Button();
            button5YMG = new Button();
            button1YMG = new Button();
            InversButtonYMG = new Button();
            CommaButtonYMG = new Button();
            QuotientButtonYMG = new Button();
            EqualButtonYMG = new Button();
            PlusButtonYMG = new Button();
            PowerButtonYMG = new Button();
            PiButtonYMG = new Button();
            ModButtonYMG = new Button();
            ExpButtonYMG = new Button();
            LogButtonYMG = new Button();
            CloseBracketButtonYMG = new Button();
            SinButtonYMG = new Button();
            OpenBracketButtonYMG = new Button();
            CosButtonYMG = new Button();
            MultiplicationButtonYMG = new Button();
            MinusButtonYMG = new Button();
            DelButtonYMG = new Button();
            RootButtonYMG = new Button();
            ScreenPanel = new Panel();
            ScreenTableLayout = new TableLayoutPanel();
            FirstPartLabelYMG = new Label();
            SecondPartLabelYMG = new Label();
            ButtonsPanel.SuspendLayout();
            TableLayoutPanel.SuspendLayout();
            ScreenPanel.SuspendLayout();
            ScreenTableLayout.SuspendLayout();
            SuspendLayout();
            // 
            // ButtonsPanel
            // 
            ButtonsPanel.Controls.Add(TableLayoutPanel);
            ButtonsPanel.Dock = DockStyle.Fill;
            ButtonsPanel.Location = new Point(0, 133);
            ButtonsPanel.Margin = new Padding(3, 4, 3, 4);
            ButtonsPanel.Name = "ButtonsPanel";
            ButtonsPanel.Size = new Size(1322, 676);
            ButtonsPanel.TabIndex = 4;
            // 
            // TableLayoutPanel
            // 
            TableLayoutPanel.BackColor = SystemColors.ActiveCaption;
            TableLayoutPanel.ColumnCount = 7;
            TableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 14.2847357F));
            TableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 14.2847357F));
            TableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 14.2847357F));
            TableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 14.2847385F));
            TableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 14.287591F));
            TableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 14.2853069F));
            TableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 14.2881632F));
            TableLayoutPanel.Controls.Add(button0YMG, 1, 3);
            TableLayoutPanel.Controls.Add(button2YMG, 1, 2);
            TableLayoutPanel.Controls.Add(button8YMG, 1, 0);
            TableLayoutPanel.Controls.Add(button9YMG, 2, 0);
            TableLayoutPanel.Controls.Add(button6YMG, 2, 1);
            TableLayoutPanel.Controls.Add(button3YMG, 2, 2);
            TableLayoutPanel.Controls.Add(button7YMG, 0, 0);
            TableLayoutPanel.Controls.Add(button4YMG, 0, 1);
            TableLayoutPanel.Controls.Add(button5YMG, 1, 1);
            TableLayoutPanel.Controls.Add(button1YMG, 0, 2);
            TableLayoutPanel.Controls.Add(InversButtonYMG, 0, 3);
            TableLayoutPanel.Controls.Add(CommaButtonYMG, 2, 3);
            TableLayoutPanel.Controls.Add(QuotientButtonYMG, 6, 1);
            TableLayoutPanel.Controls.Add(EqualButtonYMG, 6, 3);
            TableLayoutPanel.Controls.Add(PlusButtonYMG, 5, 0);
            TableLayoutPanel.Controls.Add(PowerButtonYMG, 5, 2);
            TableLayoutPanel.Controls.Add(PiButtonYMG, 3, 2);
            TableLayoutPanel.Controls.Add(ModButtonYMG, 4, 2);
            TableLayoutPanel.Controls.Add(ExpButtonYMG, 3, 3);
            TableLayoutPanel.Controls.Add(LogButtonYMG, 4, 3);
            TableLayoutPanel.Controls.Add(CloseBracketButtonYMG, 3, 1);
            TableLayoutPanel.Controls.Add(SinButtonYMG, 4, 1);
            TableLayoutPanel.Controls.Add(OpenBracketButtonYMG, 3, 0);
            TableLayoutPanel.Controls.Add(CosButtonYMG, 4, 0);
            TableLayoutPanel.Controls.Add(MultiplicationButtonYMG, 6, 0);
            TableLayoutPanel.Controls.Add(MinusButtonYMG, 5, 1);
            TableLayoutPanel.Controls.Add(DelButtonYMG, 6, 2);
            TableLayoutPanel.Controls.Add(RootButtonYMG, 5, 3);
            TableLayoutPanel.Dock = DockStyle.Fill;
            TableLayoutPanel.Location = new Point(0, 0);
            TableLayoutPanel.Margin = new Padding(3, 4, 3, 4);
            TableLayoutPanel.Name = "TableLayoutPanel";
            TableLayoutPanel.RowCount = 4;
            TableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            TableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            TableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            TableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            TableLayoutPanel.Size = new Size(1322, 676);
            TableLayoutPanel.TabIndex = 0;
            // 
            // button0YMG
            // 
            button0YMG.BackColor = SystemColors.ActiveCaption;
            button0YMG.Dock = DockStyle.Fill;
            button0YMG.FlatStyle = FlatStyle.Popup;
            button0YMG.Font = new Font("Segoe UI", 26.25F);
            button0YMG.Location = new Point(191, 511);
            button0YMG.Margin = new Padding(3, 4, 3, 4);
            button0YMG.Name = "button0YMG";
            button0YMG.Size = new Size(182, 161);
            button0YMG.TabIndex = 0;
            button0YMG.Text = "0";
            button0YMG.UseVisualStyleBackColor = false;
            button0YMG.Click += button0_Click;
            // 
            // button2YMG
            // 
            button2YMG.BackColor = SystemColors.ActiveCaption;
            button2YMG.Dock = DockStyle.Fill;
            button2YMG.FlatStyle = FlatStyle.Popup;
            button2YMG.Font = new Font("Segoe UI", 26.25F);
            button2YMG.Location = new Point(191, 342);
            button2YMG.Margin = new Padding(3, 4, 3, 4);
            button2YMG.Name = "button2YMG";
            button2YMG.Size = new Size(182, 161);
            button2YMG.TabIndex = 1;
            button2YMG.Text = "2";
            button2YMG.UseVisualStyleBackColor = false;
            button2YMG.Click += button2_Click;
            // 
            // button8YMG
            // 
            button8YMG.BackColor = SystemColors.ActiveCaption;
            button8YMG.Dock = DockStyle.Fill;
            button8YMG.FlatStyle = FlatStyle.Popup;
            button8YMG.Font = new Font("Segoe UI", 26.25F);
            button8YMG.Location = new Point(191, 4);
            button8YMG.Margin = new Padding(3, 4, 3, 4);
            button8YMG.Name = "button8YMG";
            button8YMG.Size = new Size(182, 161);
            button8YMG.TabIndex = 2;
            button8YMG.Text = "8";
            button8YMG.UseVisualStyleBackColor = false;
            button8YMG.Click += button8_Click;
            // 
            // button9YMG
            // 
            button9YMG.BackColor = SystemColors.ActiveCaption;
            button9YMG.Dock = DockStyle.Fill;
            button9YMG.FlatStyle = FlatStyle.Popup;
            button9YMG.Font = new Font("Segoe UI", 26.25F);
            button9YMG.Location = new Point(379, 4);
            button9YMG.Margin = new Padding(3, 4, 3, 4);
            button9YMG.Name = "button9YMG";
            button9YMG.Size = new Size(182, 161);
            button9YMG.TabIndex = 3;
            button9YMG.Text = "9";
            button9YMG.UseVisualStyleBackColor = false;
            button9YMG.Click += button9_Click;
            // 
            // button6YMG
            // 
            button6YMG.BackColor = SystemColors.ActiveCaption;
            button6YMG.Dock = DockStyle.Fill;
            button6YMG.FlatStyle = FlatStyle.Popup;
            button6YMG.Font = new Font("Segoe UI", 26.25F);
            button6YMG.Location = new Point(379, 173);
            button6YMG.Margin = new Padding(3, 4, 3, 4);
            button6YMG.Name = "button6YMG";
            button6YMG.Size = new Size(182, 161);
            button6YMG.TabIndex = 4;
            button6YMG.Text = "6";
            button6YMG.UseVisualStyleBackColor = false;
            button6YMG.Click += button6_Click;
            // 
            // button3YMG
            // 
            button3YMG.BackColor = SystemColors.ActiveCaption;
            button3YMG.Dock = DockStyle.Fill;
            button3YMG.FlatStyle = FlatStyle.Popup;
            button3YMG.Font = new Font("Segoe UI", 26.25F);
            button3YMG.Location = new Point(379, 342);
            button3YMG.Margin = new Padding(3, 4, 3, 4);
            button3YMG.Name = "button3YMG";
            button3YMG.Size = new Size(182, 161);
            button3YMG.TabIndex = 5;
            button3YMG.Text = "3";
            button3YMG.UseVisualStyleBackColor = false;
            button3YMG.Click += button3_Click;
            // 
            // button7YMG
            // 
            button7YMG.BackColor = SystemColors.ActiveCaption;
            button7YMG.Dock = DockStyle.Fill;
            button7YMG.FlatStyle = FlatStyle.Popup;
            button7YMG.Font = new Font("Segoe UI", 26.25F);
            button7YMG.Location = new Point(3, 4);
            button7YMG.Margin = new Padding(3, 4, 3, 4);
            button7YMG.Name = "button7YMG";
            button7YMG.Size = new Size(182, 161);
            button7YMG.TabIndex = 6;
            button7YMG.Text = "7";
            button7YMG.UseVisualStyleBackColor = false;
            button7YMG.Click += button7_Click;
            // 
            // button4YMG
            // 
            button4YMG.BackColor = SystemColors.ActiveCaption;
            button4YMG.Dock = DockStyle.Fill;
            button4YMG.FlatStyle = FlatStyle.Popup;
            button4YMG.Font = new Font("Segoe UI", 26.25F);
            button4YMG.Location = new Point(3, 173);
            button4YMG.Margin = new Padding(3, 4, 3, 4);
            button4YMG.Name = "button4YMG";
            button4YMG.Size = new Size(182, 161);
            button4YMG.TabIndex = 7;
            button4YMG.Text = "4";
            button4YMG.UseVisualStyleBackColor = false;
            button4YMG.Click += button4_Click;
            // 
            // button5YMG
            // 
            button5YMG.BackColor = SystemColors.ActiveCaption;
            button5YMG.Dock = DockStyle.Fill;
            button5YMG.FlatStyle = FlatStyle.Popup;
            button5YMG.Font = new Font("Segoe UI", 26.25F);
            button5YMG.Location = new Point(191, 173);
            button5YMG.Margin = new Padding(3, 4, 3, 4);
            button5YMG.Name = "button5YMG";
            button5YMG.Size = new Size(182, 161);
            button5YMG.TabIndex = 8;
            button5YMG.Text = "5";
            button5YMG.UseVisualStyleBackColor = false;
            button5YMG.Click += button5_Click;
            // 
            // button1YMG
            // 
            button1YMG.BackColor = SystemColors.ActiveCaption;
            button1YMG.Dock = DockStyle.Fill;
            button1YMG.FlatStyle = FlatStyle.Popup;
            button1YMG.Font = new Font("Segoe UI", 26.25F);
            button1YMG.Location = new Point(3, 342);
            button1YMG.Margin = new Padding(3, 4, 3, 4);
            button1YMG.Name = "button1YMG";
            button1YMG.Size = new Size(182, 161);
            button1YMG.TabIndex = 9;
            button1YMG.Text = "1";
            button1YMG.UseVisualStyleBackColor = false;
            button1YMG.Click += button1_Click;
            // 
            // InversButtonYMG
            // 
            InversButtonYMG.BackColor = SystemColors.ActiveCaption;
            InversButtonYMG.Dock = DockStyle.Fill;
            InversButtonYMG.FlatStyle = FlatStyle.Popup;
            InversButtonYMG.Font = new Font("Segoe UI", 26.25F);
            InversButtonYMG.Location = new Point(3, 511);
            InversButtonYMG.Margin = new Padding(3, 4, 3, 4);
            InversButtonYMG.Name = "InversButtonYMG";
            InversButtonYMG.Size = new Size(182, 161);
            InversButtonYMG.TabIndex = 10;
            InversButtonYMG.Text = "+/-";
            InversButtonYMG.UseVisualStyleBackColor = false;
            InversButtonYMG.Click += InversButton_Click;
            // 
            // CommaButtonYMG
            // 
            CommaButtonYMG.BackColor = SystemColors.ActiveCaption;
            CommaButtonYMG.Dock = DockStyle.Fill;
            CommaButtonYMG.FlatStyle = FlatStyle.Popup;
            CommaButtonYMG.Font = new Font("Segoe UI", 26.25F);
            CommaButtonYMG.Location = new Point(379, 511);
            CommaButtonYMG.Margin = new Padding(3, 4, 3, 4);
            CommaButtonYMG.Name = "CommaButtonYMG";
            CommaButtonYMG.Size = new Size(182, 161);
            CommaButtonYMG.TabIndex = 11;
            CommaButtonYMG.Text = ",";
            CommaButtonYMG.UseVisualStyleBackColor = false;
            CommaButtonYMG.Click += CommaButton_Click;
            // 
            // QuotientButtonYMG
            // 
            QuotientButtonYMG.BackColor = SystemColors.ActiveCaption;
            QuotientButtonYMG.Dock = DockStyle.Fill;
            QuotientButtonYMG.FlatStyle = FlatStyle.Popup;
            QuotientButtonYMG.Font = new Font("Segoe UI", 26.25F);
            QuotientButtonYMG.Location = new Point(1131, 173);
            QuotientButtonYMG.Margin = new Padding(3, 4, 3, 4);
            QuotientButtonYMG.Name = "QuotientButtonYMG";
            QuotientButtonYMG.Size = new Size(188, 161);
            QuotientButtonYMG.TabIndex = 13;
            QuotientButtonYMG.Text = "/";
            QuotientButtonYMG.UseVisualStyleBackColor = false;
            QuotientButtonYMG.Click += QuotientButton_Click;
            // 
            // EqualButtonYMG
            // 
            EqualButtonYMG.BackColor = SystemColors.ActiveCaption;
            EqualButtonYMG.Dock = DockStyle.Fill;
            EqualButtonYMG.FlatStyle = FlatStyle.Popup;
            EqualButtonYMG.Font = new Font("Segoe UI", 26.25F);
            EqualButtonYMG.Location = new Point(1131, 511);
            EqualButtonYMG.Margin = new Padding(3, 4, 3, 4);
            EqualButtonYMG.Name = "EqualButtonYMG";
            EqualButtonYMG.Size = new Size(188, 161);
            EqualButtonYMG.TabIndex = 15;
            EqualButtonYMG.Text = "=";
            EqualButtonYMG.UseVisualStyleBackColor = false;
            EqualButtonYMG.Click += EqualButton_Click;
            // 
            // PlusButtonYMG
            // 
            PlusButtonYMG.BackColor = SystemColors.ActiveCaption;
            PlusButtonYMG.Dock = DockStyle.Fill;
            PlusButtonYMG.FlatStyle = FlatStyle.Popup;
            PlusButtonYMG.Font = new Font("Segoe UI", 26.25F);
            PlusButtonYMG.Location = new Point(943, 4);
            PlusButtonYMG.Margin = new Padding(3, 4, 3, 4);
            PlusButtonYMG.Name = "PlusButtonYMG";
            PlusButtonYMG.Size = new Size(182, 161);
            PlusButtonYMG.TabIndex = 16;
            PlusButtonYMG.Text = "+";
            PlusButtonYMG.UseVisualStyleBackColor = false;
            PlusButtonYMG.Click += PlusButton_Click;
            // 
            // PowerButtonYMG
            // 
            PowerButtonYMG.BackColor = SystemColors.ActiveCaption;
            PowerButtonYMG.Dock = DockStyle.Fill;
            PowerButtonYMG.FlatStyle = FlatStyle.Popup;
            PowerButtonYMG.Font = new Font("Segoe UI", 26.25F);
            PowerButtonYMG.Location = new Point(943, 342);
            PowerButtonYMG.Margin = new Padding(3, 4, 3, 4);
            PowerButtonYMG.Name = "PowerButtonYMG";
            PowerButtonYMG.Size = new Size(182, 161);
            PowerButtonYMG.TabIndex = 18;
            PowerButtonYMG.Text = "^";
            PowerButtonYMG.UseVisualStyleBackColor = false;
            PowerButtonYMG.Click += PowerButton_Click;
            // 
            // PiButtonYMG
            // 
            PiButtonYMG.BackColor = SystemColors.ActiveCaption;
            PiButtonYMG.Dock = DockStyle.Fill;
            PiButtonYMG.FlatStyle = FlatStyle.Popup;
            PiButtonYMG.Font = new Font("Segoe UI", 26.25F);
            PiButtonYMG.Location = new Point(567, 342);
            PiButtonYMG.Margin = new Padding(3, 4, 3, 4);
            PiButtonYMG.Name = "PiButtonYMG";
            PiButtonYMG.Size = new Size(182, 161);
            PiButtonYMG.TabIndex = 22;
            PiButtonYMG.Text = "pi";
            PiButtonYMG.UseVisualStyleBackColor = false;
            PiButtonYMG.Click += PiButton_Click;
            // 
            // ModButtonYMG
            // 
            ModButtonYMG.BackColor = SystemColors.ActiveCaption;
            ModButtonYMG.Dock = DockStyle.Fill;
            ModButtonYMG.FlatStyle = FlatStyle.Popup;
            ModButtonYMG.Font = new Font("Segoe UI", 26.25F);
            ModButtonYMG.Location = new Point(755, 342);
            ModButtonYMG.Margin = new Padding(3, 4, 3, 4);
            ModButtonYMG.Name = "ModButtonYMG";
            ModButtonYMG.Size = new Size(182, 161);
            ModButtonYMG.TabIndex = 24;
            ModButtonYMG.Text = "mod";
            ModButtonYMG.UseVisualStyleBackColor = false;
            ModButtonYMG.Click += ModButton_Click;
            // 
            // ExpButtonYMG
            // 
            ExpButtonYMG.BackColor = SystemColors.ActiveCaption;
            ExpButtonYMG.Dock = DockStyle.Fill;
            ExpButtonYMG.FlatStyle = FlatStyle.Popup;
            ExpButtonYMG.Font = new Font("Segoe UI", 26.25F);
            ExpButtonYMG.Location = new Point(567, 511);
            ExpButtonYMG.Margin = new Padding(3, 4, 3, 4);
            ExpButtonYMG.Name = "ExpButtonYMG";
            ExpButtonYMG.Size = new Size(182, 161);
            ExpButtonYMG.TabIndex = 25;
            ExpButtonYMG.Text = "exp";
            ExpButtonYMG.UseVisualStyleBackColor = false;
            ExpButtonYMG.Click += ExpButton_Click;
            // 
            // LogButtonYMG
            // 
            LogButtonYMG.BackColor = SystemColors.ActiveCaption;
            LogButtonYMG.Dock = DockStyle.Fill;
            LogButtonYMG.FlatStyle = FlatStyle.Popup;
            LogButtonYMG.Font = new Font("Segoe UI", 26.25F);
            LogButtonYMG.Location = new Point(755, 511);
            LogButtonYMG.Margin = new Padding(3, 4, 3, 4);
            LogButtonYMG.Name = "LogButtonYMG";
            LogButtonYMG.Size = new Size(182, 161);
            LogButtonYMG.TabIndex = 23;
            LogButtonYMG.Text = "nlog(x)";
            LogButtonYMG.UseVisualStyleBackColor = false;
            LogButtonYMG.Click += LogButton_Click;
            // 
            // CloseBracketButtonYMG
            // 
            CloseBracketButtonYMG.BackColor = SystemColors.ActiveCaption;
            CloseBracketButtonYMG.Dock = DockStyle.Fill;
            CloseBracketButtonYMG.FlatStyle = FlatStyle.Popup;
            CloseBracketButtonYMG.Font = new Font("Segoe UI", 26.25F);
            CloseBracketButtonYMG.Location = new Point(567, 173);
            CloseBracketButtonYMG.Margin = new Padding(3, 4, 3, 4);
            CloseBracketButtonYMG.Name = "CloseBracketButtonYMG";
            CloseBracketButtonYMG.Size = new Size(182, 161);
            CloseBracketButtonYMG.TabIndex = 21;
            CloseBracketButtonYMG.Text = ")";
            CloseBracketButtonYMG.UseVisualStyleBackColor = false;
            CloseBracketButtonYMG.Click += CloseBracketButton_Click;
            // 
            // SinButtonYMG
            // 
            SinButtonYMG.BackColor = SystemColors.ActiveCaption;
            SinButtonYMG.Dock = DockStyle.Fill;
            SinButtonYMG.FlatStyle = FlatStyle.Popup;
            SinButtonYMG.Font = new Font("Segoe UI", 26.25F);
            SinButtonYMG.Location = new Point(755, 173);
            SinButtonYMG.Margin = new Padding(3, 4, 3, 4);
            SinButtonYMG.Name = "SinButtonYMG";
            SinButtonYMG.Size = new Size(182, 161);
            SinButtonYMG.TabIndex = 26;
            SinButtonYMG.Text = "sin";
            SinButtonYMG.UseVisualStyleBackColor = false;
            SinButtonYMG.Click += SinButton_Click;
            // 
            // OpenBracketButtonYMG
            // 
            OpenBracketButtonYMG.BackColor = SystemColors.ActiveCaption;
            OpenBracketButtonYMG.Dock = DockStyle.Fill;
            OpenBracketButtonYMG.FlatStyle = FlatStyle.Popup;
            OpenBracketButtonYMG.Font = new Font("Segoe UI", 26.25F);
            OpenBracketButtonYMG.Location = new Point(567, 4);
            OpenBracketButtonYMG.Margin = new Padding(3, 4, 3, 4);
            OpenBracketButtonYMG.Name = "OpenBracketButtonYMG";
            OpenBracketButtonYMG.Size = new Size(182, 161);
            OpenBracketButtonYMG.TabIndex = 20;
            OpenBracketButtonYMG.Text = "(";
            OpenBracketButtonYMG.UseVisualStyleBackColor = false;
            OpenBracketButtonYMG.Click += OpenBracketButton_Click;
            // 
            // CosButtonYMG
            // 
            CosButtonYMG.BackColor = SystemColors.ActiveCaption;
            CosButtonYMG.Dock = DockStyle.Fill;
            CosButtonYMG.FlatStyle = FlatStyle.Popup;
            CosButtonYMG.Font = new Font("Segoe UI", 26.25F);
            CosButtonYMG.Location = new Point(755, 4);
            CosButtonYMG.Margin = new Padding(3, 4, 3, 4);
            CosButtonYMG.Name = "CosButtonYMG";
            CosButtonYMG.Size = new Size(182, 161);
            CosButtonYMG.TabIndex = 27;
            CosButtonYMG.Text = "cos";
            CosButtonYMG.UseVisualStyleBackColor = false;
            CosButtonYMG.Click += CosButton_Click;
            // 
            // MultiplicationButtonYMG
            // 
            MultiplicationButtonYMG.BackColor = SystemColors.ActiveCaption;
            MultiplicationButtonYMG.Dock = DockStyle.Fill;
            MultiplicationButtonYMG.FlatStyle = FlatStyle.Popup;
            MultiplicationButtonYMG.Font = new Font("Segoe UI", 26.25F);
            MultiplicationButtonYMG.Location = new Point(1131, 4);
            MultiplicationButtonYMG.Margin = new Padding(3, 4, 3, 4);
            MultiplicationButtonYMG.Name = "MultiplicationButtonYMG";
            MultiplicationButtonYMG.Size = new Size(188, 161);
            MultiplicationButtonYMG.TabIndex = 17;
            MultiplicationButtonYMG.Text = "X";
            MultiplicationButtonYMG.UseVisualStyleBackColor = false;
            MultiplicationButtonYMG.Click += MultiplicationButton_Click;
            // 
            // MinusButtonYMG
            // 
            MinusButtonYMG.BackColor = SystemColors.ActiveCaption;
            MinusButtonYMG.Dock = DockStyle.Fill;
            MinusButtonYMG.FlatStyle = FlatStyle.Popup;
            MinusButtonYMG.Font = new Font("Segoe UI", 26.25F);
            MinusButtonYMG.Location = new Point(943, 173);
            MinusButtonYMG.Margin = new Padding(3, 4, 3, 4);
            MinusButtonYMG.Name = "MinusButtonYMG";
            MinusButtonYMG.Size = new Size(182, 161);
            MinusButtonYMG.TabIndex = 12;
            MinusButtonYMG.Text = "-";
            MinusButtonYMG.UseVisualStyleBackColor = false;
            MinusButtonYMG.Click += MinusButton_Click;
            // 
            // DelButtonYMG
            // 
            DelButtonYMG.BackColor = SystemColors.ActiveCaption;
            DelButtonYMG.Dock = DockStyle.Fill;
            DelButtonYMG.FlatStyle = FlatStyle.Popup;
            DelButtonYMG.Font = new Font("Segoe UI", 26.25F);
            DelButtonYMG.Location = new Point(1131, 342);
            DelButtonYMG.Margin = new Padding(3, 4, 3, 4);
            DelButtonYMG.Name = "DelButtonYMG";
            DelButtonYMG.Size = new Size(188, 161);
            DelButtonYMG.TabIndex = 14;
            DelButtonYMG.Text = " ⌦";
            DelButtonYMG.UseVisualStyleBackColor = false;
            DelButtonYMG.Click += DelButton_Click;
            // 
            // RootButtonYMG
            // 
            RootButtonYMG.BackColor = SystemColors.ActiveCaption;
            RootButtonYMG.Dock = DockStyle.Fill;
            RootButtonYMG.FlatStyle = FlatStyle.Popup;
            RootButtonYMG.Font = new Font("Segoe UI", 26.25F);
            RootButtonYMG.Location = new Point(943, 511);
            RootButtonYMG.Margin = new Padding(3, 4, 3, 4);
            RootButtonYMG.Name = "RootButtonYMG";
            RootButtonYMG.Size = new Size(182, 161);
            RootButtonYMG.TabIndex = 19;
            RootButtonYMG.Text = "√";
            RootButtonYMG.UseVisualStyleBackColor = false;
            RootButtonYMG.Click += RootButton_Click;
            // 
            // ScreenPanel
            // 
            ScreenPanel.Controls.Add(ScreenTableLayout);
            ScreenPanel.Dock = DockStyle.Top;
            ScreenPanel.Location = new Point(0, 0);
            ScreenPanel.Margin = new Padding(3, 4, 3, 4);
            ScreenPanel.Name = "ScreenPanel";
            ScreenPanel.Size = new Size(1322, 133);
            ScreenPanel.TabIndex = 5;
            // 
            // ScreenTableLayout
            // 
            ScreenTableLayout.ColumnCount = 1;
            ScreenTableLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            ScreenTableLayout.Controls.Add(FirstPartLabelYMG, 0, 0);
            ScreenTableLayout.Controls.Add(SecondPartLabelYMG, 0, 1);
            ScreenTableLayout.Dock = DockStyle.Fill;
            ScreenTableLayout.Location = new Point(0, 0);
            ScreenTableLayout.Margin = new Padding(3, 4, 3, 4);
            ScreenTableLayout.Name = "ScreenTableLayout";
            ScreenTableLayout.RowCount = 2;
            ScreenTableLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            ScreenTableLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            ScreenTableLayout.Size = new Size(1322, 133);
            ScreenTableLayout.TabIndex = 0;
            // 
            // FirstPartLabelYMG
            // 
            FirstPartLabelYMG.AutoSize = true;
            FirstPartLabelYMG.BackColor = SystemColors.ActiveCaption;
            FirstPartLabelYMG.Dock = DockStyle.Fill;
            FirstPartLabelYMG.Font = new Font("Segoe UI", 26.25F);
            FirstPartLabelYMG.ForeColor = SystemColors.ActiveCaptionText;
            FirstPartLabelYMG.Location = new Point(3, 0);
            FirstPartLabelYMG.Name = "FirstPartLabelYMG";
            FirstPartLabelYMG.Size = new Size(1316, 66);
            FirstPartLabelYMG.TabIndex = 0;
            FirstPartLabelYMG.Text = "первая половина";
            FirstPartLabelYMG.TextAlign = ContentAlignment.MiddleRight;
            // 
            // SecondPartLabelYMG
            // 
            SecondPartLabelYMG.AutoSize = true;
            SecondPartLabelYMG.BackColor = SystemColors.ActiveCaption;
            SecondPartLabelYMG.Dock = DockStyle.Fill;
            SecondPartLabelYMG.Font = new Font("Segoe UI", 26.25F);
            SecondPartLabelYMG.ForeColor = SystemColors.ActiveCaptionText;
            SecondPartLabelYMG.Location = new Point(3, 66);
            SecondPartLabelYMG.Name = "SecondPartLabelYMG";
            SecondPartLabelYMG.Size = new Size(1316, 67);
            SecondPartLabelYMG.TabIndex = 1;
            SecondPartLabelYMG.Text = "вторая половина";
            SecondPartLabelYMG.TextAlign = ContentAlignment.MiddleRight;
            // 
            // ArithmeticCalcControl
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(ButtonsPanel);
            Controls.Add(ScreenPanel);
            Margin = new Padding(3, 4, 3, 4);
            Name = "ArithmeticCalcControl";
            Size = new Size(1322, 809);
            ButtonsPanel.ResumeLayout(false);
            TableLayoutPanel.ResumeLayout(false);
            ScreenPanel.ResumeLayout(false);
            ScreenTableLayout.ResumeLayout(false);
            ScreenTableLayout.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel ButtonsPanel;
        private TableLayoutPanel TableLayoutPanel;
        private Button button0YMG;
        private Button button2YMG;
        private Button button8YMG;
        private Button button9YMG;
        private Button button6YMG;
        private Button button3YMG;
        private Button button7YMG;
        private Button button4YMG;
        private Button button5YMG;
        private Button button1YMG;
        private Button InversButtonYMG;
        private Button CommaButtonYMG;
        private Button EqualButtonYMG;
        private Button DelButtonYMG;
        private Button QuotientButtonYMG;
        private Button MinusButtonYMG;
        private Button PlusButtonYMG;
        private Button MultiplicationButtonYMG;
        private Button PowerButtonYMG;
        private Button RootButtonYMG;
        private Panel ScreenPanel;
        private TableLayoutPanel ScreenTableLayout;
        private Label FirstPartLabelYMG;
        private Label SecondPartLabelYMG;
        private Button OpenBracketButtonYMG;
        private Button CloseBracketButtonYMG;
        private Button PiButtonYMG;
        private Button LogButtonYMG;
        private Button ModButtonYMG;
        private Button ExpButtonYMG;
        private Button SinButtonYMG;
        private Button CosButtonYMG;
    }
}
