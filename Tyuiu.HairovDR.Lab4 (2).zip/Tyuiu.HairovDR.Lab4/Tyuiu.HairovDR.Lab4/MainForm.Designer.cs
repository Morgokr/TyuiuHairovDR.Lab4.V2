﻿namespace Tyuiu.HairovDR.Lab4
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            TopPanel = new Panel();
            SideBarButtonYMG = new Button();
            NameCalcLabelYMG = new Label();
            SideBarPanel = new Panel();
            BotButtonsPanel = new TableLayoutPanel();
            AboutButtonYMG = new Button();
            TopBottonPanel = new TableLayoutPanel();
            ToNDSCalcButtonYMG = new Button();
            ToConversionCalcButtonYMG = new Button();
            ToArithmeticCalcButtonYMG = new Button();
            ToOrdinaryCalcButtonYMG = new Button();
            CloseSideBarButtonYMG = new Button();
            OpenTimer = new System.Windows.Forms.Timer(components);
            CloseTimer = new System.Windows.Forms.Timer(components);
            ControlPanel = new Panel();
            TopPanel.SuspendLayout();
            SideBarPanel.SuspendLayout();
            BotButtonsPanel.SuspendLayout();
            TopBottonPanel.SuspendLayout();
            SuspendLayout();
            // 
            // TopPanel
            // 
            resources.ApplyResources(TopPanel, "TopPanel");
            TopPanel.BackColor = SystemColors.ActiveCaption;
            TopPanel.Controls.Add(SideBarButtonYMG);
            TopPanel.Controls.Add(NameCalcLabelYMG);
            TopPanel.Name = "TopPanel";
            // 
            // SideBarButtonYMG
            // 
            resources.ApplyResources(SideBarButtonYMG, "SideBarButtonYMG");
            SideBarButtonYMG.BackColor = SystemColors.ActiveCaption;
            SideBarButtonYMG.Cursor = Cursors.Hand;
            SideBarButtonYMG.ForeColor = SystemColors.ActiveCaptionText;
            SideBarButtonYMG.Name = "SideBarButtonYMG";
            SideBarButtonYMG.UseVisualStyleBackColor = false;
            SideBarButtonYMG.Click += SideBarButton_Click;
            // 
            // NameCalcLabelYMG
            // 
            resources.ApplyResources(NameCalcLabelYMG, "NameCalcLabelYMG");
            NameCalcLabelYMG.ForeColor = SystemColors.ActiveCaptionText;
            NameCalcLabelYMG.Name = "NameCalcLabelYMG";
            NameCalcLabelYMG.Click += NameCalcLabelYMG_Click;
            // 
            // SideBarPanel
            // 
            resources.ApplyResources(SideBarPanel, "SideBarPanel");
            SideBarPanel.BackColor = SystemColors.ControlDarkDark;
            SideBarPanel.Controls.Add(BotButtonsPanel);
            SideBarPanel.Controls.Add(TopBottonPanel);
            SideBarPanel.Name = "SideBarPanel";
            // 
            // BotButtonsPanel
            // 
            resources.ApplyResources(BotButtonsPanel, "BotButtonsPanel");
            BotButtonsPanel.Controls.Add(AboutButtonYMG, 0, 0);
            BotButtonsPanel.Name = "BotButtonsPanel";
            // 
            // AboutButtonYMG
            // 
            resources.ApplyResources(AboutButtonYMG, "AboutButtonYMG");
            AboutButtonYMG.BackColor = SystemColors.GradientActiveCaption;
            AboutButtonYMG.Cursor = Cursors.Hand;
            AboutButtonYMG.Name = "AboutButtonYMG";
            AboutButtonYMG.UseVisualStyleBackColor = false;
            AboutButtonYMG.Click += AboutButtonYMG_Click;
            // 
            // TopBottonPanel
            // 
            resources.ApplyResources(TopBottonPanel, "TopBottonPanel");
            TopBottonPanel.Controls.Add(ToNDSCalcButtonYMG, 0, 4);
            TopBottonPanel.Controls.Add(ToConversionCalcButtonYMG, 0, 3);
            TopBottonPanel.Controls.Add(ToArithmeticCalcButtonYMG, 0, 2);
            TopBottonPanel.Controls.Add(ToOrdinaryCalcButtonYMG, 0, 1);
            TopBottonPanel.Controls.Add(CloseSideBarButtonYMG, 0, 0);
            TopBottonPanel.Name = "TopBottonPanel";
            // 
            // ToNDSCalcButtonYMG
            // 
            resources.ApplyResources(ToNDSCalcButtonYMG, "ToNDSCalcButtonYMG");
            ToNDSCalcButtonYMG.BackColor = SystemColors.GradientActiveCaption;
            ToNDSCalcButtonYMG.Cursor = Cursors.Hand;
            ToNDSCalcButtonYMG.Name = "ToNDSCalcButtonYMG";
            ToNDSCalcButtonYMG.UseVisualStyleBackColor = false;
            ToNDSCalcButtonYMG.Click += ToNDSCalcButton_Click;
            // 
            // ToConversionCalcButtonYMG
            // 
            resources.ApplyResources(ToConversionCalcButtonYMG, "ToConversionCalcButtonYMG");
            ToConversionCalcButtonYMG.BackColor = SystemColors.GradientActiveCaption;
            ToConversionCalcButtonYMG.Cursor = Cursors.Hand;
            ToConversionCalcButtonYMG.Name = "ToConversionCalcButtonYMG";
            ToConversionCalcButtonYMG.UseVisualStyleBackColor = false;
            ToConversionCalcButtonYMG.Click += ToConversionCalcButton_Click;
            // 
            // ToArithmeticCalcButtonYMG
            // 
            resources.ApplyResources(ToArithmeticCalcButtonYMG, "ToArithmeticCalcButtonYMG");
            ToArithmeticCalcButtonYMG.BackColor = SystemColors.GradientActiveCaption;
            ToArithmeticCalcButtonYMG.Cursor = Cursors.Hand;
            ToArithmeticCalcButtonYMG.Name = "ToArithmeticCalcButtonYMG";
            ToArithmeticCalcButtonYMG.UseVisualStyleBackColor = false;
            ToArithmeticCalcButtonYMG.Click += ToArithmeticCalcButton_Click;
            // 
            // ToOrdinaryCalcButtonYMG
            // 
            resources.ApplyResources(ToOrdinaryCalcButtonYMG, "ToOrdinaryCalcButtonYMG");
            ToOrdinaryCalcButtonYMG.BackColor = SystemColors.GradientActiveCaption;
            ToOrdinaryCalcButtonYMG.Cursor = Cursors.Hand;
            ToOrdinaryCalcButtonYMG.Name = "ToOrdinaryCalcButtonYMG";
            ToOrdinaryCalcButtonYMG.UseVisualStyleBackColor = false;
            ToOrdinaryCalcButtonYMG.Click += ToOrdinaryCalcButton_Click;
            // 
            // CloseSideBarButtonYMG
            // 
            resources.ApplyResources(CloseSideBarButtonYMG, "CloseSideBarButtonYMG");
            CloseSideBarButtonYMG.BackColor = SystemColors.GradientActiveCaption;
            CloseSideBarButtonYMG.Cursor = Cursors.Hand;
            CloseSideBarButtonYMG.Name = "CloseSideBarButtonYMG";
            CloseSideBarButtonYMG.UseVisualStyleBackColor = false;
            CloseSideBarButtonYMG.Click += CloseSideBarButton_Click;
            // 
            // OpenTimer
            // 
            OpenTimer.Interval = 1;
            OpenTimer.Tick += OpenTimer_Tick;
            // 
            // CloseTimer
            // 
            CloseTimer.Enabled = true;
            CloseTimer.Interval = 1;
            CloseTimer.Tick += CloseTimer_Tick;
            // 
            // ControlPanel
            // 
            resources.ApplyResources(ControlPanel, "ControlPanel");
            ControlPanel.BackColor = SystemColors.Window;
            ControlPanel.BackgroundImage = Properties.Resources.asmodeus_helluva;
            ControlPanel.Name = "ControlPanel";
            // 
            // MainForm
            // 
            resources.ApplyResources(this, "$this");
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.asmodeus_helluva;
            Controls.Add(SideBarPanel);
            Controls.Add(ControlPanel);
            Controls.Add(TopPanel);
            Name = "MainForm";
            Load += MainForm_Load;
            TopPanel.ResumeLayout(false);
            TopPanel.PerformLayout();
            SideBarPanel.ResumeLayout(false);
            BotButtonsPanel.ResumeLayout(false);
            TopBottonPanel.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel TopPanel;
        private Label NameCalcLabelYMG;
        private Panel SideBarPanel;
        private System.Windows.Forms.Timer OpenTimer;
        private System.Windows.Forms.Timer CloseTimer;
        private TableLayoutPanel TopBottonPanel;
        private TableLayoutPanel BotButtonsPanel;
        private Button ToOrdinaryCalcButtonYMG;
        private Button ToArithmeticCalcButtonYMG;
        private Button ToConversionCalcButtonYMG;
        private Button ToNDSCalcButtonYMG;
        private Button SideBarButtonYMG;
        private Button CloseSideBarButtonYMG;
        private Panel ControlPanel;
        private Button AboutButtonYMG;
    }
}
