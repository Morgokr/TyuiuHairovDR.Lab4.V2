﻿namespace Tyuiu.HairovDR.Lab4
{
    partial class NDSCalcControl
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            BackGrounPanel = new Panel();
            SeporatorPanel = new TableLayoutPanel();
            SecondFormulaPanel = new TableLayoutPanel();
            SecondFormulaSecondPanel = new TableLayoutPanel();
            NDSLabel2YMG = new Label();
            SecondFormulaSecondTextBoxYMG = new TextBox();
            SecondFormulaFirstPanel = new TableLayoutPanel();
            SummaNDSLabelYMG = new Label();
            SecondFormulaFirstTextBox = new TextBox();
            SecondFormulaButtonYMG = new Button();
            ResultSummaNDSLabel = new Label();
            SummaWithNDSLabel = new Label();
            FirstFormulaPanel = new TableLayoutPanel();
            FirstFormulaButtonYMG = new Button();
            FirstFormulaFirstPanel = new TableLayoutPanel();
            SummaLabelYMG = new Label();
            FirstFormulaFirstTextBoxYMG = new TextBox();
            FirstFormulaSecondPanel = new TableLayoutPanel();
            NDSLabelYMG = new Label();
            FirstFormulaSecondTextBoxYMG = new TextBox();
            ResultNDSLabel = new Label();
            SummaWithoutNDSLabel = new Label();
            BackGrounPanel.SuspendLayout();
            SeporatorPanel.SuspendLayout();
            SecondFormulaPanel.SuspendLayout();
            SecondFormulaSecondPanel.SuspendLayout();
            SecondFormulaFirstPanel.SuspendLayout();
            FirstFormulaPanel.SuspendLayout();
            FirstFormulaFirstPanel.SuspendLayout();
            FirstFormulaSecondPanel.SuspendLayout();
            SuspendLayout();
            // 
            // BackGrounPanel
            // 
            BackGrounPanel.BackColor = SystemColors.ActiveCaption;
            BackGrounPanel.Controls.Add(SeporatorPanel);
            BackGrounPanel.Dock = DockStyle.Fill;
            BackGrounPanel.Location = new Point(0, 0);
            BackGrounPanel.Margin = new Padding(3, 4, 3, 4);
            BackGrounPanel.Name = "BackGrounPanel";
            BackGrounPanel.Size = new Size(1401, 907);
            BackGrounPanel.TabIndex = 0;
            // 
            // SeporatorPanel
            // 
            SeporatorPanel.BackColor = SystemColors.ActiveCaption;
            SeporatorPanel.ColumnCount = 2;
            SeporatorPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            SeporatorPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            SeporatorPanel.Controls.Add(SecondFormulaPanel, 1, 0);
            SeporatorPanel.Controls.Add(FirstFormulaPanel, 0, 0);
            SeporatorPanel.Dock = DockStyle.Fill;
            SeporatorPanel.Location = new Point(0, 0);
            SeporatorPanel.Margin = new Padding(3, 4, 3, 4);
            SeporatorPanel.Name = "SeporatorPanel";
            SeporatorPanel.RowCount = 1;
            SeporatorPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            SeporatorPanel.Size = new Size(1401, 907);
            SeporatorPanel.TabIndex = 0;
            // 
            // SecondFormulaPanel
            // 
            SecondFormulaPanel.BackColor = SystemColors.ActiveCaption;
            SecondFormulaPanel.ColumnCount = 1;
            SecondFormulaPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            SecondFormulaPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 23F));
            SecondFormulaPanel.Controls.Add(SecondFormulaSecondPanel, 0, 1);
            SecondFormulaPanel.Controls.Add(SecondFormulaFirstPanel, 0, 0);
            SecondFormulaPanel.Controls.Add(SecondFormulaButtonYMG, 0, 2);
            SecondFormulaPanel.Controls.Add(ResultSummaNDSLabel, 0, 3);
            SecondFormulaPanel.Controls.Add(SummaWithNDSLabel, 0, 4);
            SecondFormulaPanel.Dock = DockStyle.Fill;
            SecondFormulaPanel.Location = new Point(703, 4);
            SecondFormulaPanel.Margin = new Padding(3, 4, 3, 4);
            SecondFormulaPanel.Name = "SecondFormulaPanel";
            SecondFormulaPanel.RowCount = 5;
            SecondFormulaPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            SecondFormulaPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            SecondFormulaPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            SecondFormulaPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            SecondFormulaPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            SecondFormulaPanel.Size = new Size(695, 899);
            SecondFormulaPanel.TabIndex = 1;
            // 
            // SecondFormulaSecondPanel
            // 
            SecondFormulaSecondPanel.BackColor = SystemColors.ActiveCaption;
            SecondFormulaSecondPanel.ColumnCount = 2;
            SecondFormulaSecondPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            SecondFormulaSecondPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            SecondFormulaSecondPanel.Controls.Add(NDSLabel2YMG, 0, 0);
            SecondFormulaSecondPanel.Controls.Add(SecondFormulaSecondTextBoxYMG, 1, 0);
            SecondFormulaSecondPanel.Dock = DockStyle.Fill;
            SecondFormulaSecondPanel.Location = new Point(3, 183);
            SecondFormulaSecondPanel.Margin = new Padding(3, 4, 3, 4);
            SecondFormulaSecondPanel.Name = "SecondFormulaSecondPanel";
            SecondFormulaSecondPanel.RowCount = 1;
            SecondFormulaSecondPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            SecondFormulaSecondPanel.Size = new Size(689, 171);
            SecondFormulaSecondPanel.TabIndex = 4;
            // 
            // NDSLabel2YMG
            // 
            NDSLabel2YMG.AutoSize = true;
            NDSLabel2YMG.BackColor = SystemColors.ActiveCaption;
            NDSLabel2YMG.Dock = DockStyle.Fill;
            NDSLabel2YMG.Font = new Font("Segoe UI", 15.75F);
            NDSLabel2YMG.ForeColor = SystemColors.ActiveCaptionText;
            NDSLabel2YMG.Location = new Point(3, 0);
            NDSLabel2YMG.Name = "NDSLabel2YMG";
            NDSLabel2YMG.Size = new Size(338, 171);
            NDSLabel2YMG.TabIndex = 0;
            NDSLabel2YMG.Text = "Процентная ставка НДС";
            NDSLabel2YMG.TextAlign = ContentAlignment.TopRight;
            // 
            // SecondFormulaSecondTextBoxYMG
            // 
            SecondFormulaSecondTextBoxYMG.BackColor = SystemColors.ActiveCaption;
            SecondFormulaSecondTextBoxYMG.Dock = DockStyle.Fill;
            SecondFormulaSecondTextBoxYMG.Font = new Font("Segoe UI", 15.75F);
            SecondFormulaSecondTextBoxYMG.Location = new Point(347, 4);
            SecondFormulaSecondTextBoxYMG.Margin = new Padding(3, 4, 3, 4);
            SecondFormulaSecondTextBoxYMG.Name = "SecondFormulaSecondTextBoxYMG";
            SecondFormulaSecondTextBoxYMG.Size = new Size(339, 42);
            SecondFormulaSecondTextBoxYMG.TabIndex = 1;
            // 
            // SecondFormulaFirstPanel
            // 
            SecondFormulaFirstPanel.BackColor = SystemColors.ActiveCaption;
            SecondFormulaFirstPanel.ColumnCount = 2;
            SecondFormulaFirstPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            SecondFormulaFirstPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            SecondFormulaFirstPanel.Controls.Add(SummaNDSLabelYMG, 0, 0);
            SecondFormulaFirstPanel.Controls.Add(SecondFormulaFirstTextBox, 1, 0);
            SecondFormulaFirstPanel.Dock = DockStyle.Fill;
            SecondFormulaFirstPanel.Location = new Point(3, 4);
            SecondFormulaFirstPanel.Margin = new Padding(3, 4, 3, 4);
            SecondFormulaFirstPanel.Name = "SecondFormulaFirstPanel";
            SecondFormulaFirstPanel.RowCount = 1;
            SecondFormulaFirstPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            SecondFormulaFirstPanel.Size = new Size(689, 171);
            SecondFormulaFirstPanel.TabIndex = 3;
            // 
            // SummaNDSLabelYMG
            // 
            SummaNDSLabelYMG.AutoSize = true;
            SummaNDSLabelYMG.BackColor = SystemColors.ActiveCaption;
            SummaNDSLabelYMG.Dock = DockStyle.Fill;
            SummaNDSLabelYMG.Font = new Font("Segoe UI", 15.75F);
            SummaNDSLabelYMG.ForeColor = SystemColors.ControlText;
            SummaNDSLabelYMG.Location = new Point(3, 0);
            SummaNDSLabelYMG.Name = "SummaNDSLabelYMG";
            SummaNDSLabelYMG.Size = new Size(338, 171);
            SummaNDSLabelYMG.TabIndex = 0;
            SummaNDSLabelYMG.Text = "Сумма продукта без НДС";
            SummaNDSLabelYMG.TextAlign = ContentAlignment.TopRight;
            // 
            // SecondFormulaFirstTextBox
            // 
            SecondFormulaFirstTextBox.BackColor = SystemColors.ActiveCaption;
            SecondFormulaFirstTextBox.Dock = DockStyle.Fill;
            SecondFormulaFirstTextBox.Font = new Font("Segoe UI", 15.75F);
            SecondFormulaFirstTextBox.Location = new Point(347, 4);
            SecondFormulaFirstTextBox.Margin = new Padding(3, 4, 3, 4);
            SecondFormulaFirstTextBox.Name = "SecondFormulaFirstTextBox";
            SecondFormulaFirstTextBox.Size = new Size(339, 42);
            SecondFormulaFirstTextBox.TabIndex = 1;
            // 
            // SecondFormulaButtonYMG
            // 
            SecondFormulaButtonYMG.BackColor = SystemColors.ActiveCaption;
            SecondFormulaButtonYMG.Dock = DockStyle.Fill;
            SecondFormulaButtonYMG.FlatStyle = FlatStyle.Popup;
            SecondFormulaButtonYMG.Font = new Font("Segoe UI", 15.75F);
            SecondFormulaButtonYMG.Location = new Point(3, 362);
            SecondFormulaButtonYMG.Margin = new Padding(3, 4, 3, 4);
            SecondFormulaButtonYMG.Name = "SecondFormulaButtonYMG";
            SecondFormulaButtonYMG.Size = new Size(689, 171);
            SecondFormulaButtonYMG.TabIndex = 0;
            SecondFormulaButtonYMG.Text = "Рассчитать второй вариант\r\n";
            SecondFormulaButtonYMG.UseVisualStyleBackColor = false;
            SecondFormulaButtonYMG.Click += SecondFormulaButton_Click;
            // 
            // ResultSummaNDSLabel
            // 
            ResultSummaNDSLabel.AutoSize = true;
            ResultSummaNDSLabel.BackColor = SystemColors.ActiveCaption;
            ResultSummaNDSLabel.Dock = DockStyle.Fill;
            ResultSummaNDSLabel.Font = new Font("Segoe UI", 15.75F);
            ResultSummaNDSLabel.ForeColor = SystemColors.ControlLightLight;
            ResultSummaNDSLabel.Location = new Point(3, 537);
            ResultSummaNDSLabel.Name = "ResultSummaNDSLabel";
            ResultSummaNDSLabel.Size = new Size(689, 179);
            ResultSummaNDSLabel.TabIndex = 5;
            ResultSummaNDSLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // SummaWithNDSLabel
            // 
            SummaWithNDSLabel.AutoSize = true;
            SummaWithNDSLabel.BackColor = SystemColors.ActiveCaption;
            SummaWithNDSLabel.Dock = DockStyle.Fill;
            SummaWithNDSLabel.FlatStyle = FlatStyle.Popup;
            SummaWithNDSLabel.Font = new Font("Segoe UI", 15.75F);
            SummaWithNDSLabel.ForeColor = SystemColors.ControlLightLight;
            SummaWithNDSLabel.Location = new Point(3, 716);
            SummaWithNDSLabel.Name = "SummaWithNDSLabel";
            SummaWithNDSLabel.Size = new Size(689, 183);
            SummaWithNDSLabel.TabIndex = 6;
            SummaWithNDSLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // FirstFormulaPanel
            // 
            FirstFormulaPanel.BackColor = SystemColors.ActiveCaption;
            FirstFormulaPanel.ColumnCount = 1;
            FirstFormulaPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            FirstFormulaPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 23F));
            FirstFormulaPanel.Controls.Add(FirstFormulaButtonYMG, 0, 2);
            FirstFormulaPanel.Controls.Add(FirstFormulaFirstPanel, 0, 0);
            FirstFormulaPanel.Controls.Add(FirstFormulaSecondPanel, 0, 1);
            FirstFormulaPanel.Controls.Add(ResultNDSLabel, 0, 3);
            FirstFormulaPanel.Controls.Add(SummaWithoutNDSLabel, 0, 4);
            FirstFormulaPanel.Dock = DockStyle.Fill;
            FirstFormulaPanel.Location = new Point(3, 4);
            FirstFormulaPanel.Margin = new Padding(3, 4, 3, 4);
            FirstFormulaPanel.Name = "FirstFormulaPanel";
            FirstFormulaPanel.RowCount = 5;
            FirstFormulaPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            FirstFormulaPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            FirstFormulaPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            FirstFormulaPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            FirstFormulaPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            FirstFormulaPanel.Size = new Size(694, 899);
            FirstFormulaPanel.TabIndex = 0;
            // 
            // FirstFormulaButtonYMG
            // 
            FirstFormulaButtonYMG.BackColor = SystemColors.ActiveCaption;
            FirstFormulaButtonYMG.Dock = DockStyle.Fill;
            FirstFormulaButtonYMG.FlatStyle = FlatStyle.Popup;
            FirstFormulaButtonYMG.Font = new Font("Segoe UI", 15.75F);
            FirstFormulaButtonYMG.Location = new Point(3, 362);
            FirstFormulaButtonYMG.Margin = new Padding(3, 4, 3, 4);
            FirstFormulaButtonYMG.Name = "FirstFormulaButtonYMG";
            FirstFormulaButtonYMG.Size = new Size(688, 171);
            FirstFormulaButtonYMG.TabIndex = 0;
            FirstFormulaButtonYMG.Text = "Рассчитать первый вариант";
            FirstFormulaButtonYMG.UseVisualStyleBackColor = false;
            FirstFormulaButtonYMG.Click += FirstFormulaButton_Click;
            // 
            // FirstFormulaFirstPanel
            // 
            FirstFormulaFirstPanel.BackColor = SystemColors.ActiveCaption;
            FirstFormulaFirstPanel.ColumnCount = 2;
            FirstFormulaFirstPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            FirstFormulaFirstPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            FirstFormulaFirstPanel.Controls.Add(SummaLabelYMG, 0, 0);
            FirstFormulaFirstPanel.Controls.Add(FirstFormulaFirstTextBoxYMG, 1, 0);
            FirstFormulaFirstPanel.Dock = DockStyle.Fill;
            FirstFormulaFirstPanel.Location = new Point(3, 4);
            FirstFormulaFirstPanel.Margin = new Padding(3, 4, 3, 4);
            FirstFormulaFirstPanel.Name = "FirstFormulaFirstPanel";
            FirstFormulaFirstPanel.RowCount = 1;
            FirstFormulaFirstPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            FirstFormulaFirstPanel.Size = new Size(688, 171);
            FirstFormulaFirstPanel.TabIndex = 1;
            // 
            // SummaLabelYMG
            // 
            SummaLabelYMG.AutoSize = true;
            SummaLabelYMG.BackColor = SystemColors.ActiveCaption;
            SummaLabelYMG.Dock = DockStyle.Fill;
            SummaLabelYMG.FlatStyle = FlatStyle.Popup;
            SummaLabelYMG.Font = new Font("Segoe UI", 15.75F);
            SummaLabelYMG.ForeColor = SystemColors.ControlText;
            SummaLabelYMG.Location = new Point(3, 0);
            SummaLabelYMG.Name = "SummaLabelYMG";
            SummaLabelYMG.Size = new Size(338, 171);
            SummaLabelYMG.TabIndex = 0;
            SummaLabelYMG.Text = "Сумма с НДС";
            SummaLabelYMG.TextAlign = ContentAlignment.TopRight;
            // 
            // FirstFormulaFirstTextBoxYMG
            // 
            FirstFormulaFirstTextBoxYMG.BackColor = SystemColors.ActiveCaption;
            FirstFormulaFirstTextBoxYMG.Dock = DockStyle.Fill;
            FirstFormulaFirstTextBoxYMG.Font = new Font("Segoe UI", 15.75F);
            FirstFormulaFirstTextBoxYMG.Location = new Point(347, 4);
            FirstFormulaFirstTextBoxYMG.Margin = new Padding(3, 4, 3, 4);
            FirstFormulaFirstTextBoxYMG.Name = "FirstFormulaFirstTextBoxYMG";
            FirstFormulaFirstTextBoxYMG.Size = new Size(338, 42);
            FirstFormulaFirstTextBoxYMG.TabIndex = 1;
            // 
            // FirstFormulaSecondPanel
            // 
            FirstFormulaSecondPanel.BackColor = SystemColors.ActiveCaption;
            FirstFormulaSecondPanel.ColumnCount = 2;
            FirstFormulaSecondPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            FirstFormulaSecondPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            FirstFormulaSecondPanel.Controls.Add(NDSLabelYMG, 0, 0);
            FirstFormulaSecondPanel.Controls.Add(FirstFormulaSecondTextBoxYMG, 1, 0);
            FirstFormulaSecondPanel.Dock = DockStyle.Fill;
            FirstFormulaSecondPanel.Location = new Point(3, 183);
            FirstFormulaSecondPanel.Margin = new Padding(3, 4, 3, 4);
            FirstFormulaSecondPanel.Name = "FirstFormulaSecondPanel";
            FirstFormulaSecondPanel.RowCount = 1;
            FirstFormulaSecondPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            FirstFormulaSecondPanel.Size = new Size(688, 171);
            FirstFormulaSecondPanel.TabIndex = 2;
            // 
            // NDSLabelYMG
            // 
            NDSLabelYMG.AutoSize = true;
            NDSLabelYMG.BackColor = SystemColors.ActiveCaption;
            NDSLabelYMG.Dock = DockStyle.Fill;
            NDSLabelYMG.Font = new Font("Segoe UI", 15.75F);
            NDSLabelYMG.ForeColor = SystemColors.ControlText;
            NDSLabelYMG.Location = new Point(3, 0);
            NDSLabelYMG.Name = "NDSLabelYMG";
            NDSLabelYMG.Size = new Size(338, 171);
            NDSLabelYMG.TabIndex = 0;
            NDSLabelYMG.Text = "Процентная ставка НДС";
            NDSLabelYMG.TextAlign = ContentAlignment.TopRight;
            // 
            // FirstFormulaSecondTextBoxYMG
            // 
            FirstFormulaSecondTextBoxYMG.BackColor = SystemColors.ActiveCaption;
            FirstFormulaSecondTextBoxYMG.Dock = DockStyle.Fill;
            FirstFormulaSecondTextBoxYMG.Font = new Font("Segoe UI", 15.75F);
            FirstFormulaSecondTextBoxYMG.Location = new Point(347, 4);
            FirstFormulaSecondTextBoxYMG.Margin = new Padding(3, 4, 3, 4);
            FirstFormulaSecondTextBoxYMG.Name = "FirstFormulaSecondTextBoxYMG";
            FirstFormulaSecondTextBoxYMG.Size = new Size(338, 42);
            FirstFormulaSecondTextBoxYMG.TabIndex = 1;
            // 
            // ResultNDSLabel
            // 
            ResultNDSLabel.AutoSize = true;
            ResultNDSLabel.BackColor = SystemColors.ActiveCaption;
            ResultNDSLabel.Dock = DockStyle.Fill;
            ResultNDSLabel.Font = new Font("Segoe UI", 15.75F);
            ResultNDSLabel.ForeColor = SystemColors.ControlLightLight;
            ResultNDSLabel.Location = new Point(3, 537);
            ResultNDSLabel.Name = "ResultNDSLabel";
            ResultNDSLabel.Size = new Size(688, 179);
            ResultNDSLabel.TabIndex = 3;
            ResultNDSLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // SummaWithoutNDSLabel
            // 
            SummaWithoutNDSLabel.AutoSize = true;
            SummaWithoutNDSLabel.BackColor = SystemColors.ActiveCaption;
            SummaWithoutNDSLabel.Dock = DockStyle.Fill;
            SummaWithoutNDSLabel.Font = new Font("Segoe UI", 15.75F);
            SummaWithoutNDSLabel.ForeColor = SystemColors.ControlLightLight;
            SummaWithoutNDSLabel.Location = new Point(3, 716);
            SummaWithoutNDSLabel.Name = "SummaWithoutNDSLabel";
            SummaWithoutNDSLabel.Size = new Size(688, 183);
            SummaWithoutNDSLabel.TabIndex = 4;
            SummaWithoutNDSLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // NDSCalcControl
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(BackGrounPanel);
            Margin = new Padding(3, 4, 3, 4);
            Name = "NDSCalcControl";
            Size = new Size(1401, 907);
            BackGrounPanel.ResumeLayout(false);
            SeporatorPanel.ResumeLayout(false);
            SecondFormulaPanel.ResumeLayout(false);
            SecondFormulaPanel.PerformLayout();
            SecondFormulaSecondPanel.ResumeLayout(false);
            SecondFormulaSecondPanel.PerformLayout();
            SecondFormulaFirstPanel.ResumeLayout(false);
            SecondFormulaFirstPanel.PerformLayout();
            FirstFormulaPanel.ResumeLayout(false);
            FirstFormulaPanel.PerformLayout();
            FirstFormulaFirstPanel.ResumeLayout(false);
            FirstFormulaFirstPanel.PerformLayout();
            FirstFormulaSecondPanel.ResumeLayout(false);
            FirstFormulaSecondPanel.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel BackGrounPanel;
        private TableLayoutPanel SeporatorPanel;
        private TableLayoutPanel SecondFormulaPanel;
        private TableLayoutPanel FirstFormulaPanel;
        private Button SecondFormulaButtonYMG;
        private Button FirstFormulaButtonYMG;
        private TableLayoutPanel SecondFormulaSecondPanel;
        private Label NDSLabel2YMG;
        private TableLayoutPanel SecondFormulaFirstPanel;
        private Label SummaNDSLabelYMG;
        private TableLayoutPanel FirstFormulaFirstPanel;
        private Label SummaLabelYMG;
        private TableLayoutPanel FirstFormulaSecondPanel;
        private Label NDSLabelYMG;
        private TextBox SecondFormulaSecondTextBoxYMG;
        private TextBox SecondFormulaFirstTextBox;
        private TextBox FirstFormulaFirstTextBoxYMG;
        private TextBox FirstFormulaSecondTextBoxYMG;
        private Label ResultSummaNDSLabel;
        private Label SummaWithNDSLabel;
        private Label ResultNDSLabel;
        private Label SummaWithoutNDSLabel;
    }
}
